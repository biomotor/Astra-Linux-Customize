#!/bin/bash

sudo cp -r $PWD/Pastel_L9 /usr/share/fly-wm/decorations
sudo cp $PWD/Pastel_L9.colors /usr/share/color-schemes
sudo cp $PWD/Pastel_L.png /usr/share/wallpapers/Pastel_L.png

THEME=$HOME/.fly/theme

# Files
PALETTERC=$HOME/.fly/paletterc
CURRENTRC=$HOME/.fly/theme/current.themerc
BREEZERC=$HOME/.config/breezerc
TROLLTECH=$HOME/.config/Trolltech.conf

# Подготовка файлов цветовой схемы:
mv $BREEZERC $BREEZERC.bak
sed -e '
s|DecorationFocus=.*|DecorationFocus=#96c0dd;|;
s|DecorationHover=.*|DecorationHover=#abcde4;|
' $BREEZERC.bak > $BREEZERC

mv $PALETTERC $PALETTERC.bak
sed -e '
s|BackgroundColor=.*|BackgroundColor=#ebebeb|;
s|ColorScheme=.*|ColorScheme=/usr/share/color-schemes/Pastel_L9.colors|;
s|PrimaryColor=.*|PrimaryColor=#96c0dd|
' $PALETTERC.bak > $PALETTERC

mv $TROLLTECH $TROLLTECH.bak
sed -e '
s|Palette\\active=.*|Palette\\active=#232627, #ebebeb, #ffffff, #f5f5f5, #727272, #bdbdbd, #232627, #ffffff, #232627, #ffffff, #ebebeb, #3d3d3d, #96c0dd, #fcfcfc, #2980b9, #7f8c8d, #eff0f1, #000000, #fcfcfc, #232627, #ffffff|;
s|Palette\\disabled=.*|Palette\\disabled=#9d9e9f, #e0e0e0, #ffffff, #ebebeb, #6d6d6d, #b6b6b6, #aaabab, #ffffff, #9d9e9f, #f3f3f3, #e0e0e0, #3d3d3d, #e0e0e0, #9d9e9f, #a3cae2, #c8cdcd, #e3e5e7, #000000, #fcfcfc, #232627, #ffffff|;
s|Palette\\inactive=.*|Palette\\inactive=#232627, #ebebeb, #ffffff, #f5f5f5, #727272, #bdbdbd, #232627, #ffffff, #232627, #ffffff, #ebebeb, #3d3d3d, #caddeb, #232627, #2980b9, #7f8c8d, #eff0f1, #000000, #fcfcfc, #232627, #ffffff|
' $TROLLTECH.bak > $TROLLTECH

# Применение цветовой схемы
fly-wmfunc FLYWM_UPDATE_VAL ColorScheme Pastel_L9

# Подготовка файлов декораций, обоев и логотипа
mv $CURRENTRC $CURRENTRC.bak
sed -e '
s|ButtonActiveColor=.*|ButtonActiveColor=#dedede|;
s|ButtonColor=.*|ButtonColor=#dedede|;
s|ButtonStringActiveColor=.*|ButtonStringActiveColor=#000000|;
s|ButtonStringColor=.*|ButtonStringColor=#000000|;
s|ClockStringColor=.*|ClockStringColor=#000000|;
s|DialogColor=.*|DialogColor=#ebebeb|;
s|DialogStringColor=.*|DialogStringColor=#000000|;
s|FrameActiveColor=.*|FrameActiveColor=#96c0dd|;
s|FrameActiveOutlineColor=.*|FrameActiveOutlineColor=#8fb1c9|;
s|FrameColor=.*|FrameColor=#96c0dc|;
s|FrameOutlineColor=.*|FrameOutlineColor=#b5b5b5|;
s|IconActiveColor=.*|IconActiveColor=#dedede|;
s|IconBackColor=.*|IconBackColor=#ebebeb|;
s|IconForeColor=.*|IconForeColor=#000000|;
s|IconStringActiveColor=.*|IconStringActiveColor=#000000|;
s|IconStringColor=.*|IconStringColor=white|;
s|LogoPosition=.*|LogoPosition=NotShow|;
s|MenuActiveColor=.*|MenuActiveColor=#f5f5f5|;
s|MenuColor=.*|MenuColor=#ebebeb|;
s|MenuColor2=.*|MenuColor2=#ebebeb|;
s|MenuStringActiveColor=.*|MenuStringActiveColor=#000000|;
s|MenuStringColor=.*|MenuStringColor=#000000|;
s|MiniatureColor=.*|MiniatureColor=#000000|;
s|PagerActiveColor=.*|PagerActiveColor=#dedede|;
s|PagerColor=.*|PagerColor=#ebebeb|;
s|PagerColor2=.*|PagerColor2=#ebebeb|;
s|SwitcherColor=.*|SwitcherColor=#ebebeb|;
s|SwitcherStringActiveColor=.*|SwitcherStringActiveColor=#000000|;
s|SwitcherStringColor=.*|SwitcherStringColor=#000000|;
s|TaskbarColor=.*|TaskbarColor=#ebebeb|;
s|TaskbarStringActiveColor=.*|TaskbarStringActiveColor=#000000|;
s|TaskbarStringColor=.*|TaskbarStringColor=#000000|;
s|TitleStringActiveColor=.*|TitleStringActiveColor=#000000|;
s|TitleStringColor=.*|TitleStringColor=#000000|;
s|TitlebarActiveColor=.*|TitlebarActiveColor=#96c0dd|;
s|TitlebarActiveColor2=.*|TitlebarActiveColor2=#96c0dd|;
s|TitlebarColor=.*|TitlebarColor=#96c0dc|;
s|TitlebarColor2=.*|TitlebarColor2=#96c0dc|;
s|WallPaper=.*|WallPaper="/usr/share/wallpapers/Pastel_L.png"|
' $CURRENTRC.bak > $CURRENTRC

# Применение декораций, обоев и логотипа
fly-wmfunc FLYWM_UPDATE_VAL DecorTheme Pastel_L9
fly-wmfunc FLYWM_UPDATE_VAL WallPaper /usr/share/wallpapers/Pastel_L.png
fly-wmfunc FLYWM_UPDATE_VAL LogoPosition NotShow

# Возвращаем переменную декорации после сброса
echo 'DecorTheme="Pastel_L9"' >> $CURRENTRC

# Перезапускаем проводник
fly-wmfunc FLYWM_RESTART


























